#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
knowledge-graph - Ontology v2.0
Advanced knowledge graph system with entity recognition, relation extraction, graph query and visualization

Version: 2.0.0
"""

__version__ = "2.0.0"
__author__ = "CoPaw Contributors"
__license__ = "MIT"

from .cli import main

if __name__ == '__main__':
    main()